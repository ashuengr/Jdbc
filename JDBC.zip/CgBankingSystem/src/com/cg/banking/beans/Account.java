package com.cg.banking.beans;
import java.util.List;
public class Account
{
 private long accountNo;
 private float initBalance;
 private int pinNumber;
 private String accountType,accountStatus;
 private float accountBalance;
 private List<Transaction>Transactions;
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public int getPinNumber() {
	return pinNumber;
}
public void setPinNumber(int pinNumber) {
	this.pinNumber = pinNumber;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getAccountStatus() {
	return accountStatus;
}
public void setAccountStatus(String accountStatus) {
	this.accountStatus = accountStatus;
}
public float getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(float accountBalance) {
	this.accountBalance = accountBalance;
}
public List<Transaction> getTransactions() {
	return Transactions;
}
public void setTransactions(List<Transaction> transactions) {
	Transactions = transactions;
}
public Account(long accountNo, int pinNumber, String accountType, String accountStatus, float accountBalance,
		List<Transaction> transactions) {
	super();
	this.accountNo = accountNo;
	this.pinNumber = pinNumber;
	this.accountType = accountType;
	this.accountStatus = accountStatus;
	this.accountBalance = accountBalance;
	Transactions = transactions;
}
public Account(long accountNo, String accountType) {
	super();
	this.accountNo = accountNo;
	this.accountType = accountType;
}
public Account(String accountType,float initBalance) {
	this.accountType = accountType;
	this.initBalance=initBalance;
}
public Account() {
	super();
}
}
