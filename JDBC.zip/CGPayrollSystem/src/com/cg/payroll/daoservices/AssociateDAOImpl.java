package com.cg.payroll.daoservices;
import com.cg.payroll.util.PayrollDBUtil;
import java.util.List;

import java.util.ArrayList;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollDBUtil;

public class AssociateDAOImpl implements AssociateDao {

	@Override
	public Associate save(Associate associate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Associate associate) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Associate findOne(int associateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Associate> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
