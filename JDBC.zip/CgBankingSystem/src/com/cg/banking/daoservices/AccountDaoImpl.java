package com.cg.banking.daoservices;

public class AccountDaoImpl {

}
